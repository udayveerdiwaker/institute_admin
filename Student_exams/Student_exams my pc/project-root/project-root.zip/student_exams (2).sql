-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 25, 2024 at 07:51 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_exams`
--

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `id` int(11) NOT NULL,
  `question_number` int(11) NOT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT 0,
  `options` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`id`, `question_number`, `is_correct`, `options`) VALUES
(1, 1, 1, 'Application'),
(2, 1, 0, 'Compiler'),
(3, 1, 0, 'System'),
(4, 1, 0, 'Programming'),
(5, 2, 0, 'Italic'),
(6, 2, 1, 'Magic tool'),
(7, 2, 0, 'Font'),
(8, 2, 0, 'Bold'),
(9, 3, 0, ' MS Word 2003'),
(10, 3, 0, 'MS Word 2007'),
(11, 3, 0, 'MS Word 2010'),
(12, 3, 1, 'MS Word 1020'),
(13, 4, 0, 'Clipart'),
(14, 4, 1, 'Margins'),
(15, 4, 0, 'Header'),
(16, 4, 0, 'Footer'),
(17, 5, 0, 'Document formatting'),
(18, 5, 0, 'Database management'),
(19, 5, 1, 'Mail merge'),
(20, 5, 0, ' Form letters'),
(21, 6, 0, '.exe'),
(22, 6, 1, '.doc'),
(23, 6, 0, '.png'),
(24, 6, 0, '.jpeg'),
(25, 7, 1, 'Text wrapping'),
(26, 7, 0, 'Indent'),
(27, 7, 0, 'Clipart'),
(28, 7, 0, 'Line spacing'),
(29, 8, 0, 'Home panel'),
(30, 8, 0, 'Ribbon'),
(31, 8, 1, 'View option toolbar'),
(32, 8, 0, 'Title bar'),
(33, 9, 1, 'Calibri'),
(34, 9, 0, 'vrinda'),
(35, 9, 0, 'Times New Roman'),
(36, 9, 0, 'Cambria'),
(37, 10, 1, 'Page Border'),
(38, 10, 0, 'Margins'),
(39, 10, 0, 'Orientation'),
(40, 10, 0, 'Line Numbers'),
(41, 11, 0, 'Computer understands only C Language'),
(42, 11, 0, 'Computer understands only Assembly Language'),
(43, 11, 1, 'Computer understands only Binary Language'),
(44, 11, 0, 'Computer understands only BASIC'),
(45, 12, 0, 'Output Unit'),
(46, 12, 1, 'Input Unit'),
(47, 12, 0, 'Memory Unit'),
(48, 12, 0, 'Arithmetic & Logic Unit'),
(49, 13, 0, 'Commonly Occupied Machines Used in Technical and Educational Research'),
(50, 13, 0, 'Commonly Operated Machines Purposely Used in Technical and Environmental Research'),
(51, 13, 0, 'Commonly Oriented Machines Used in Technical and Educational Research'),
(52, 13, 1, 'Common Operating Machine Purposely Used for Technological and Educational Research'),
(53, 14, 0, 'Computer understands only C Language'),
(54, 14, 0, 'Computer understands only Assembly Language'),
(55, 14, 1, 'Computer understands only Binary Language'),
(56, 14, 0, 'Computer understands only BASIC'),
(57, 15, 1, 'Hardware'),
(58, 15, 0, 'Software'),
(59, 15, 0, 'System Software'),
(60, 15, 0, 'Package'),
(61, 16, 0, 'James Gosling'),
(62, 16, 1, 'Charles Babbage'),
(63, 16, 0, 'Dennis Ritchie'),
(64, 16, 0, 'Bjarne Stroustrup'),
(65, 17, 0, 'Aling To The Center'),
(66, 17, 0, 'Aling To The Right Side'),
(67, 17, 0, 'Cut'),
(68, 17, 0, 'None of These'),
(69, 18, 0, 'Find The Image'),
(70, 18, 0, 'Find The Color'),
(71, 18, 0, ' Cut'),
(72, 18, 1, ' Find The Text'),
(73, 19, 0, ' F1'),
(74, 19, 0, 'F5'),
(75, 19, 1, ' F7'),
(76, 19, 0, ' F12'),
(77, 20, 0, ' CDs and DVDs'),
(78, 20, 0, ' Primary and Secondary'),
(79, 20, 1, ' RAM and ROM'),
(80, 20, 0, ' External Memory'),
(81, 21, 1, 'Spreadsheet?'),
(82, 21, 0, 'Database Management'),
(83, 21, 0, 'Presentation'),
(84, 21, 0, 'Workbook'),
(85, 22, 0, '4,81,0576'),
(86, 22, 1, '1,048,576'),
(87, 22, 0, '1,57,648'),
(88, 22, 0, '1,63, 84'),
(89, 23, 1, ' 1, 2, 3,...'),
(90, 23, 0, ' A, B, C,...'),
(91, 23, 0, 'A1, B1, C1, ....'),
(92, 23, 0, ' I, II, III,...'),
(93, 24, 0, 'Arithmetic'),
(94, 24, 0, 'Conditional'),
(95, 24, 1, 'Logical'),
(96, 24, 0, 'Greater'),
(97, 25, 0, '=IF (logical_test, TRUE([value_if_true]), FALSE([value_if_false]))'),
(98, 25, 1, '=IF (logical_test, [value_if_true], [value_if_false])'),
(99, 25, 0, '=IF (logical_test, {[value_if_true]}, {[value_if_false]})'),
(100, 25, 0, '=IF (logical_test: [value_if_true] , [value_if_false])'),
(101, 26, 1, 'Counts cells as specified'),
(102, 26, 0, 'Counts blank cells in a range'),
(103, 26, 0, 'Counts cells with numbers in a range'),
(104, 26, 0, 'Returns values based on a TRUE or FALSE condition'),
(105, 27, 0, '/'),
(106, 27, 0, 'f'),
(107, 27, 1, '='),
(108, 27, 0, '?'),
(109, 28, 1, 'Ctrl+K'),
(110, 28, 0, 'Ctrl+H'),
(111, 28, 0, 'Ctrl+J'),
(112, 28, 0, 'Ctrl+F'),
(113, 29, 0, 'Ctrl+B'),
(114, 29, 0, 'Ctrl+I'),
(115, 29, 0, 'Ctrl+O'),
(116, 29, 1, 'Ctrl+N'),
(117, 30, 0, 'Data management'),
(118, 30, 0, 'Accounting'),
(119, 30, 0, 'Programming'),
(120, 30, 1, 'All Of Above'),
(121, 31, 1, '400%'),
(122, 31, 0, '300%'),
(123, 31, 0, '200%'),
(124, 31, 0, '100%'),
(125, 32, 0, 'Ctrl + F'),
(126, 32, 0, 'Ctrl + O'),
(127, 32, 1, ' Ctrl + M'),
(128, 32, 0, 'Ctrl + N'),
(129, 33, 0, 'Picture'),
(130, 33, 0, 'Gradient'),
(131, 33, 0, 'Texture'),
(132, 33, 1, 'All of the above'),
(133, 34, 0, 'Ms- Word'),
(134, 34, 0, 'Ms- Excel'),
(135, 34, 0, 'Ms- Access'),
(136, 34, 0, 'Ms - Power point'),
(137, 35, 0, 'Transition tab'),
(138, 35, 1, 'Design Tab'),
(139, 35, 0, 'Insert Tab'),
(140, 35, 0, 'Animation Tab'),
(141, 36, 1, 'F5'),
(142, 36, 0, 'F11'),
(143, 36, 0, 'F7'),
(144, 36, 0, 'shift+ F5'),
(145, 37, 1, 'Exretreme animation'),
(146, 37, 0, 'Slide show'),
(147, 37, 0, 'Slide sorter'),
(148, 37, 0, 'Normal'),
(149, 38, 0, 'COMMA'),
(150, 38, 0, 'HYPEN'),
(151, 38, 1, 'ESC'),
(152, 38, 0, 'TAB'),
(153, 39, 0, 'Comment Box'),
(154, 39, 0, 'Text Layer'),
(155, 39, 0, 'Note Box'),
(156, 39, 1, 'Text Box'),
(157, 40, 0, 'View'),
(158, 40, 1, 'Insert'),
(159, 40, 0, 'Edit'),
(160, 40, 0, 'File'),
(162, 41, 0, 'Ctrl+M'),
(163, 41, 0, 'Ctrl+B'),
(164, 41, 0, 'Ctrl+J'),
(165, 41, 1, 'Ctrl+N'),
(166, 42, 0, '3'),
(167, 42, 0, '4'),
(168, 42, 1, '5'),
(169, 42, 0, '6'),
(170, 43, 1, 'Artificial Intelligence '),
(171, 43, 0, 'Programming Intelligence '),
(172, 43, 0, 'System Knowledge '),
(173, 43, 0, 'None Of These '),
(174, 44, 0, 'Microsoft Word '),
(175, 44, 0, 'Microsoft Excel '),
(176, 44, 1, 'Microsoft Windows '),
(177, 44, 0, 'Microsoft Access '),
(178, 45, 0, 'Mainframe'),
(179, 45, 1, 'Super computer '),
(180, 45, 0, 'Micro Computer '),
(181, 45, 0, 'None of These'),
(182, 46, 0, 'Keyboard'),
(183, 46, 0, 'Mouse'),
(184, 46, 1, 'Speaker '),
(185, 46, 0, 'Scanner '),
(186, 47, 0, 'SUM'),
(187, 47, 0, 'MIN'),
(188, 47, 1, 'SUBTRACT'),
(189, 47, 0, 'MAX'),
(190, 48, 0, 'Powerpoint'),
(191, 48, 0, 'PowerPoint'),
(192, 48, 0, 'Pwrpoint'),
(193, 48, 1, 'Powerpnt'),
(198, 49, 1, 'True'),
(199, 49, 0, 'False'),
(200, 49, 0, 'Cant Say'),
(201, 49, 0, 'May Be'),
(202, 50, 0, ' Computer Processing Unit'),
(203, 50, 0, ' Central Peripheral Unit'),
(204, 50, 1, ' Central Processing Unit'),
(205, 50, 0, ' Computer Processing User');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `question_number` int(11) NOT NULL,
  `question_text` varchar(300) NOT NULL,
  `subject` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`question_number`, `question_text`, `subject`) VALUES
(1, 'Microsoft word is ____ software.?', 'Computer'),
(2, 'Which is not in MS Word?', 'Computer'),
(3, 'Which is not an edition of MS Word?', 'Computer'),
(4, 'What is the blank space outside the printing area on a page?', 'Computer'),
(5, 'The ability to combine name and addresses with a standard document is called ________', 'Computer'),
(6, 'The valid format of MS Word is ___?.', 'Computer'),
(7, '_____ is the change the way text warps around the selected object.', 'Computer'),
(8, 'In the _____ we can change the view of the document and set the zoom option.', 'Computer'),
(9, 'What is thw default font of a Microsoft word 2007 Document.', 'Computer'),
(10, 'Which Option is not available in the page setup group of page layout tab ', 'Computer'),
(11, 'Which of the following language does the computer understand?', 'Computer'),
(12, 'Which of the following unit is responsible for converting the data received from the user into a computer understandable format?', 'Computer'),
(13, 'Which of the following is the correct abbreviation of COMPUTER?', 'Computer'),
(14, 'Which of the following language does the computer understand?', 'Computer'),
(15, 'Which of the following are physical devices of a computer?', 'Computer'),
(16, 'Who is the father of Computers?', 'Computer'),
(17, 'It is done by CTRL+E .', 'Computer'),
(18, 'It is done by CTRL+F .', 'Computer'),
(19, 'Which of the following is a shortcut key for \"spelling and Grammar ?  ', 'Computer'),
(20, 'Two Kinds of Main Memory are ?', 'Computer'),
(21, 'What is MS Excel?', 'Computer'),
(22, 'What is the row limit of MS Excel 2019? ', 'Computer'),
(23, 'In Microsoft Excel spreadsheets, rows are designated as _______?', 'Computer'),
(24, 'The Greater Than sign (>) exemplifies a/an _____ operator.', 'Computer'),
(25, '____ is the correct syntax of IF() Function. ', 'Computer'),
(26, 'Why is the =COUNTIF function in Excel used? ', 'Computer'),
(27, 'What do Excel formulas start with? ', 'Computer'),
(28, 'How to Open the Insert hyperlink dialog box? ', 'Computer'),
(29, 'What is shortcut key to open an existing workbook?', 'Computer'),
(30, 'What is Excel used for?', 'Computer'),
(31, 'What is the Max Zoom percentage in MS PowerPoint?', 'Computer'),
(32, 'In the current presentation, if we want to insert a new slide, we can choose which of these?', 'Computer'),
(33, 'Which of the following fill effects can be used to fill the background of the slide?', 'Computer'),
(34, 'Slides Are prepared in ?', 'Computer'),
(35, 'In power point, Themes could befound Under- ', 'Computer'),
(36, 'In Ms powerpoint ,key used to run the slide show from the beginning is -', 'Computer'),
(37, 'Which type of view is not present in MS-PowerPoint? ', 'Computer'),
(38, 'Which of the Following Sortcut keys is used to end a Powerpoint Persentation? ', 'Computer'),
(39, 'What do we use if we want to add texts in a given slide?', 'Computer'),
(40, 'From which of these menus can we access a Text Box, Picture, Chart etc.?', 'Computer'),
(41, 'which of the following shortcut key to open new Blank Document in ms word ? ', 'Computer'),
(42, 'In how many generation a computer can be classified ?', 'Computer'),
(43, 'Fifth genration computer are based on ? ', 'Computer'),
(44, 'Which one of the Following is an example of oprating system ? ', 'Computer'),
(45, 'Which of the following is the powerful type of the computer ?', 'Computer'),
(46, 'Which one is not an input device?', 'Computer'),
(47, '____ is not a function in Excel.', 'Computer'),
(48, 'What we have to type in the Run dialog box to open Powerpoint?', 'Computer'),
(49, 'In PowerPoint, is it allowed to make a PDF of the powerpoint presentation?', 'Computer'),
(50, 'What does CPU stand for?', 'Computer'),
(51, 'What is Syntax of C Language?', 'C++'),
(101, 'HTML Stand for?', 'Web Development'),
(151, 'What is Tally?', 'Tally');

-- --------------------------------------------------------

--
-- Table structure for table `registered_user`
--

CREATE TABLE `registered_user` (
  `id` int(10) NOT NULL,
  `fname` text DEFAULT NULL,
  `lname` text DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registered_user`
--

INSERT INTO `registered_user` (`id`, `fname`, `lname`, `username`, `password`) VALUES
(2, 'sonia', 'singh', 'ss730439@gmail.com', 'sonia123'),
(3, 'Arnav', 'Mandal', 'Arnavmandal@', 'Arnavmandal@'),
(4, 'shiva', 'divaker', 'udayveer2@gmail.com', 'shiva@1234'),
(94, 'Sagar', 'Bhatt', 'sagarbhatt7451@gmail.com', 'Sagar@321'),
(96, 'Sagar', 'Bhatt', 'sagarbhatt7451@gmail.com', 'Sagar@010101'),
(97, 'Shiva', 'Divakar', 'sagarbhatt7451@gmail.com', 'sonia123'),
(98, 'Shiva', 'Divakar', 'sagarbhatt7451@gmail.com', 'sonia123');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `id` int(10) NOT NULL,
  `student_name` varchar(25) NOT NULL,
  `student_marks` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`id`, `student_name`, `student_marks`) VALUES
(1, 'ss730439@gmail.com', '46'),
(2, 'Arnavmandal@', '37'),
(4, 'udayveer2@gmail.com', '30'),
(5, 'sagarbhatt7451@gmail.com', '3'),
(6, 'sagarbhatt7451@gmail.com', '3'),
(7, 'sagarbhatt7451@gmail.com', '3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`question_number`);

--
-- Indexes for table `registered_user`
--
ALTER TABLE `registered_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `options`
--
ALTER TABLE `options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=206;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `question_number` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=408;

--
-- AUTO_INCREMENT for table `registered_user`
--
ALTER TABLE `registered_user`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;

--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
