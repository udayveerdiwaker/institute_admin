<?php include_once "connection.php";
session_start();
//get question by subject name





//Set Questions Number

$number = $_GET['n'];

//query for the questions
// $query = "SELECT q.*, o.options FROM questions q , options o WHERE q.subject ='$number' and q.question_number = o.question_number;";

$query = "SELECT question_text FROM questions WHERE $number";

// $query = "SELECT * FROM `questions` WHERE subject =$number;";

//get the questions
$result = mysqli_query($conn, $query);
$question = mysqli_fetch_assoc($result);




//Get Choice
$query1 = "SELECT * FROM options WHERE question_number = $number";
$choices = mysqli_query($conn, $query1);


// print_r($choices);
// exit();


//Get the total questions
$query = "SELECT * FROM questions";
$total_questions = mysqli_num_rows(mysqli_query($conn, $query));

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <link rel="stylesheet" href="questionstyle.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>exam</title>
</head>

<body>
  <div class="container">
    <h2 class="display-6 mt-2">Welcome To You <?php //echo $_SESSION['user_name'] ?></h2>


    <div class="me-5 d-grid gap-2 d-md-flex justify-content-end">
      <a href="logout.php">
        <button class="btn btn-warning" type="button">Logout</button>
      </a>
    </div>

    <div class="heading">
      <h6 class="text-center card-header fs-4" ><?php echo $_SESSION['user_name'] ?> You have to select only 1 correct answer out of 4 options.</h6>
    </div>
    <div class="maindiv mt-5">
      <div class="current text-center">Question <?php echo $number; ?> of <?php echo $total_questions; ?></div>

      <p class=" card questions card-header bg-white" id="qcard"><?php echo $number; ?> : <?php echo $question['question_text'] ?></p>
<div>
      <form action="process.php" method="POST">
        <ol>
          <?php while ($row = mysqli_fetch_assoc($choices)) { 
            
            ?>
            <li>
              <input name="choice" class="form-check-input p-2" type="radio" name="radioNoLabel" id="radioNoLabel1" value="<?php echo $row['id']; ?>">
              <?php echo $row['options']; ?>
            </li>
          <?php } ?>
        </ol>
        <input type="hidden" name="number" value="<?php echo $number ?>;">
        <input type="submit" name="submit" value="Submit">
        
      </form>
      </div>
    </div>
    <div id="cite">
      <cite>
      All Copyright © Reserved by - Computer Sikhe & Website Banaye
      </cite>
      
    </div>
  </div>

</body>

</html>